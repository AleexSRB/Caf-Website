(function () {
  const slides = document.querySelectorAll('.slideshow .slide');
  const dots = document.querySelectorAll('.dots button');
  const captionEl = document.getElementById('caption');
  const captions = [
    { title: 'A warm welcome', text: 'Cozy corners, brick walls, golden hours.' },
    { title: 'Crafted with care', text: 'Single-origin espresso, pulled to perfection.' },
    { title: 'Baked each morning', text: 'Flaky croissants & fresh pastries daily.' },
  ];
  let index = 0;
  let timer;

  function show(i) {
    index = (i + slides.length) % slides.length;
    slides.forEach((s, n) => s.classList.toggle('active', n === index));
    dots.forEach((d, n) => d.classList.toggle('active', n === index));
    captionEl.querySelector('h2').textContent = captions[index].title;
    captionEl.querySelector('p').textContent = captions[index].text;
  }
  function next() { show(index + 1); }
  function prev() { show(index - 1); }
  function restart() { clearInterval(timer); timer = setInterval(next, 5000); }

  document.querySelector('.nav-btn.next').addEventListener('click', () => { next(); restart(); });
  document.querySelector('.nav-btn.prev').addEventListener('click', () => { prev(); restart(); });
  dots.forEach((d, n) => d.addEventListener('click', () => { show(n); restart(); }));

  restart();
})();
